<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    function  __construct() {
        parent::__construct();
        $this->load->model('General_model');
        $this->load->library(array('session','user_agent','form_validation'));

        if ($this->session->userdata('user_id') != '' ){
        }
        else
        {
            redirect('Signout');
        }
       }
	public function index()
	{
        if(isset($_POST['date_filter'])) 
        {
        $filter_date = $_POST['date_filter'];
        $data['item_list'] = $this->General_model->filter_item_list($filter_date);
        }else{
        $data['item_list'] = $this->General_model->item_list();
        }
        $this->load->view('index',$data);
	}
    public function add()
	{
		$this->load->view('add');
	}
    public function update($id)
	{
        $data['item'] = $this->General_model->itemById($id);
		$this->load->view('update',$data);
	}
    public function store()
    {
        $this->db->insert('tbl_items', $_POST);
        redirect('home');
    }

    public function update_item()
    {
       $ID = $this->input->post('item_id');
       $data = array(
                'item_name' => $this->input->post('item_name'),
                'quantity'=> $this->input->post('quantity'),
                'status'=> $this->input->post('status'),
                'created_at'=> $this->input->post('created_at')
                );
        $this->db->where('id', $ID);
        $update = $this->db->update('tbl_items', $data);
        redirect('home');
    }
    public function delete($id)
    {
        $delete = $this->General_model->delete($id);
        redirect('home');
    }
}
