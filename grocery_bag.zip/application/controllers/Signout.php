<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Signout extends CI_controller{
    function __construct()
    {
        parent::__construct();
        $this->load->helper(array('url','form'));
        $this->load->library('session');
    }
    public function index()
    {
            $this->session->sess_destroy();
            redirect('login_controller');
    }
}
?>