<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_controller extends CI_Controller {

    function  __construct() {
        parent::__construct();
        $this->load->library(array('session','user_agent','form_validation'));
        $this->load->model('General_model');
       }
	public function index()
	{
        $this->load->view('login');
	}
    public function validate()
    {
        $this->form_validation->set_rules('user_name','user name','required');
        $this->form_validation->set_rules('password','Password','required');
        if($this->form_validation->run()==FALSE)
        {
            $this->session->set_flashdata('error',validation_errors());
            redirect($this->agent->referrer());
        }
        else
        {
            $resultad=$this->General_model->loginCheck();
            $data['user_id']=$resultad['id'];
            if($this->session->userdata('user_id') != '')
            {
                redirect('home');
            }
            else
            {
                redirect($this->agent->referrer());
            }
        }
    }


}
