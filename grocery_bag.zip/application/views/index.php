<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>View List</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
        <div class="container mt-5">
            <!-- top -->
            <div class="row">
                <div class="col-lg-12">
                    <h1>View Grocery List</h1>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-8 float-left">
                   <form method="post" action="<?=base_url('home')?>" > 
                     <div class="row">
                        <div class="col-lg-8">
                            <!-- Date Filtering-->
                            <input type="date" name="date_filter" class="form-control">
                        </div>
                        <div class="col-lg-4">
                            <input type="submit" class="btn btn-danger" value="filter">
                        </div>
                     </div>
                    </form>
                </div>
                <div class="col-lg-4 float-right">
                <a href="<?=base_url('home/add')?>" ><button class="btn btn-success">Add Item</button></a>
                <a href="<?=base_url('Signout')?>" ><button class="btn btn-warning">Signout</button></a>
                </div>
            </div>
            <!-- // top -->
            <!-- Grocery Cards -->
            <div class="row mt-4">
                <!--- -->
                <!-- Loop This -->
               <?php foreach($item_list as $res_item){?>
                <div class="col-lg-4">
                    <div class="card">
                        <div class="card-body">
                          <h5 class="card-title"><?=$res_item['item_name']?></h5>
                          <h6 class="card-subtitle mb-2 text-muted"><?=$res_item['quantity']?></h6>
                          <p class="text-success"><?=$res_item['status']?></p>
                         <a href="<?=base_url()?>Home/update/<?=$res_item['id']?>"> <button class="btn btn-success">Edit</button></a>
                         <a href="<?=base_url()?>Home/delete/<?=$res_item['id']?>" onclick="return confirm('Are you sure, You want to delete this item?')"> <button class="btn btn-danger">Delete</button></a>
                        </div>
                      </div>
                </div>
                <?php } ?>
                <!-- // Loop -->
               

            </div>
        </div>
    </body>
</html>
