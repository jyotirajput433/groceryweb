<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Login</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
        <div class="container mt-5">
            <h1>User Login</h1>
            <form method="POST" action="<?=base_url('Login_controller/validate')?>">
                <div class="form-group">
                    <label>User Name</label>
                    <input type="text" class="form-control col-sm-4" required name="user_name" placeholder="User Name"/>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="text" class="form-control col-sm-4" required name="password" placeholder="*******"/>
                </div>
                <div class="form-group">
                    <input type="submit" value="Login" class="btn btn-danger">
                </div>
            </form>
        </div>
    </body> 
</html>
