<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Add List</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
        <div class="container mt-5">
            <h1>Add Grocery List</h1>
            <form method="POST" action="<?=base_url('Home/store')?>">
                <div class="form-group">
                    <label>Item name</label>
                    <input type="text" class="form-control" required name="item_name" placeholder="Item name"/>
                </div>
                <div class="form-group">
                    <label>Item quantity</label>
                    <input type="text" class="form-control" required name="quantity" placeholder="Item quantity"/>
                </div>
                <div class="form-group">
                    <label>Item status</label>
                    <select class="form-control" name="status" required>
                        <option value="PENDING">PENDING</option>
                        <option value="BOUGHT">BOUGHT</option>
                        <option value="NOT AVAILABLE">NOT AVAILABLE</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Date</label>
                    <input type="date" name="created_at" class="form-control" required placeholder="Date">
                </div>
                <div class="form-group">
                    <input type="submit" value="Add" class="btn btn-danger">
                </div>
            </form>
        </div>
    </body> 
</html>
