<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Update List</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
        <div class="container mt-5">
            <h1>Update Grocery List</h1>
            <form action="<?=base_url('home/update_item')?>" method="POST">
                <div class="form-group">
                    <label>Item name</label>
                    <input type="hidden" name="item_id" value="<?=$item['0']['id']?>">
                    <input type="text" name="item_name" class="form-control" placeholder="Item name" value="<?=$item['0']['item_name']?>"/>
                </div>
                <div class="form-group">
                    <label>Item quantity</label>
                    <input type="text" name="quantity" class="form-control" placeholder="Item quantity" value="<?=$item['0']['item_name']?>"/>
                </div>
                <div class="form-group">
                    <label>Item status</label>
                    <select class="form-control" name="status">
                        <option <?php if($item['0']['status'] == 'PENDING'){ echo 'selected=selected' ;} ?>value="PENDING">PENDING</option>
                        <option <?php if($item['0']['status'] == 'BOUGHT'){ echo 'selected=selected' ;} ?>value="BOUGHT">BOUGHT</option>
                        <option <?php if($item['0']['status'] == 'NOT AVAILABLE'){ echo 'selected=selected';} ?>value="NOT AVAILABLE">NOT AVAILABLE</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Date</label>
                    <input type="date" name="created_at" class="form-control" placeholder="Date" value="<?=date_format(date_create($item['0']['created_at']),"Y-m-d"); ?>">
                </div>
                <div class="form-group">
                    <input type="submit" value="Update" class="btn btn-danger">
                </div>
            </form>
        </div>
    </body> 
</html>
