<?php
class General_model extends CI_Model
{
   
    public function item_list()
    {
        $this->db->select('*');
        $this->db->from('tbl_items');
        $this->db->where('is_deleted',0);
        $query = $this->db->get();
        return $query->result_array();
    }
    public function filter_item_list($date)
    {
        $this->db->select('*');
        $this->db->from('tbl_items');
        $this->db->where('is_deleted',0);
        $this->db->where('DATE_FORMAT(created_at, "%Y-%m-%d") = ',$date);
        $query = $this->db->get();
        return $query->result_array();
    }

    public function itemById($id)
    {
        $this->db->select('*');
        $this->db->from('tbl_items');
        $this->db->where('id',$id);
        $query = $this->db->get();
        return $query->result_array();
    }

    public function delete($id)
    {
        $data = array(
            'is_deleted' => 1,
            'deleted_time'=> date('Y-m-d H:i:s')
            );
        $this->db->where('id', $id);
        $update = $this->db->update('tbl_items', $data);
        return true; 
    
    }

    function loginCheck()
    {
        $this->db->where('user_name', $this->input->post('user_name'));
        $result = $this->db->count_all_results('userdetails');

        if ($result == 1) {
            $this->db->where('user_name', $this->input->post('user_name'));
            $this->db->where('password', $this->input->post('password'));
            $result1 = $this->db->get('userdetails');

            $res1 = $result1->row();
            if (count($res1) == 1) {
                $dataAdmin = array(
                    'id' => $res1->id,
                    'user_name' => $res1->user_name,
                );
                    $this->session->set_userdata('user_id', $dataAdmin['id']);
                    return $dataAdmin;
                

            } else {
                $this->session->set_flashdata('error', 'Your Password is Incorrect !');
                redirect($this->agent->referrer());
            }
        } else {
            $this->session->set_flashdata('error', 'Incorrect Credentials !');
            redirect($this->agent->referrer());
        }

    }
  
}